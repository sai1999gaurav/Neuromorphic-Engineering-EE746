function problem_5d(m_syn_stimulus_1, V_t_1, m_syn_stimulus_2, V_t_2)
syn_strength = problem_5b(m_syn_stimulus_1, V_t_1);
%Problem 5c
problem_5c(syn_strength, m_syn_stimulus_2, m_syn_stimulus_1, V_t_1, 2);
end